<?php
include 'index.php';
var_dump(checkGmail('sjadsalamfdsfdsf123@gmail.com'));